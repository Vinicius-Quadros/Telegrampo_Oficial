<?php
include "db.php";

$nome = $_POST['nome'];
$email = $_POST['email'];

$sql = "UPDATE usuarios SET nome='$nome' WHERE email='$email'";
if ($conn->query($sql) === TRUE) {
    echo "Usuário atualizado!";
} else {
    echo "Erro: " . $conn->error;
}
$conn->close();
?>
