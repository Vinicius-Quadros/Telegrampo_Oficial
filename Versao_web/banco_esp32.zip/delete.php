<?php
include "db.php";

$email = $_POST['email'];

$sql = "DELETE FROM usuarios WHERE email='$email'";
if ($conn->query($sql) === TRUE) {
    echo "Usuário apagado!";
} else {
    echo "Erro: " . $conn->error;
}
$conn->close();
?>
