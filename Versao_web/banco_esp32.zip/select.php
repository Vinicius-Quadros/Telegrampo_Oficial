<?php
include "db.php";

$sql = "SELECT * FROM usuarios";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<ul>";
    while($row = $result->fetch_assoc()) {
        echo "<li>".$row["id"]." - ".$row["nome"]." (".$row["email"].")</li>";
    }
    echo "</ul>";
} else {
    echo "Nenhum usuário encontrado.";
}
$conn->close();
?>
