<?php
require_once '../includes/auth.php';
requireAuth();

$current_user = getCurrentUser();

// Buscar dispositivos do usuário
$dispositivos = fetchAll("SELECT * FROM dispositivos WHERE id_usuario = ? ORDER BY criado_em DESC", 
                        [$current_user['id_usuario']]);

// Buscar leituras recentes dos dispositivos do usuário
$leituras_recentes = fetchAll("SELECT l.*, d.nome as dispositivo_nome, s.tipo_sensor, s.unidade_medida 
                               FROM leituras l 
                               JOIN dispositivos d ON l.id_dispositivo = d.id_dispositivo 
                               JOIN sensores s ON l.id_sensor = s.id_sensor 
                               WHERE d.id_usuario = ? 
                               ORDER BY l.data_hora DESC 
                               LIMIT 20", [$current_user['id_usuario']]);

// Buscar notificações não lidas do usuário
$notificacoes = fetchAll("SELECT * FROM notificacoes 
                          WHERE id_usuario = ? AND lida = FALSE 
                          ORDER BY data_hora DESC 
                          LIMIT 10", [$current_user['id_usuario']]);

// Contar estatísticas do usuário
$total_dispositivos = count($dispositivos);
$total_leituras = countRecords('leituras l JOIN dispositivos d ON l.id_dispositivo = d.id_dispositivo', 
                               'd.id_usuario = ?', [$current_user['id_usuario']]);
$notificacoes_nao_lidas = count($notificacoes);

// Processar atualização de perfil
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $dados = [
        'nome' => sanitize($_POST['nome']),
        'celular' => sanitize($_POST['celular'])
    ];
    
    // Se há nova senha, incluir
    if (!empty($_POST['nova_senha'])) {
        if ($_POST['nova_senha'] !== $_POST['confirmar_senha']) {
            $error = 'As senhas não coincidem!';
        } elseif (strlen($_POST['nova_senha']) < 6) {
            $error = 'A senha deve ter pelo menos 6 caracteres!';
        } else {
            $dados['senha'] = $_POST['nova_senha'];
        }
    }
    
    if (!isset($error)) {
        $result = updateUser($current_user['id_usuario'], $dados);
        if ($result['success']) {
            $success = $result['message'];
            $current_user = getCurrentUser(); // Recarregar dados
        } else {
            $error = $result['message'];
        }
    }
}

// Marcar notificação como lida
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    $id_notificacao = $_GET['mark_read'];
    executeQuery("UPDATE notificacoes SET lida = TRUE WHERE id_notificacao = ? AND id_usuario = ?", 
                [$id_notificacao, $current_user['id_usuario']]);
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Dashboard - Grampo IoT</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }

        .header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 1.8rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 0.9rem;
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-1px);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 1.5rem;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: #666;
            font-weight: 600;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .card h3 {
            color: #333;
            margin-bottom: 1rem;
            font-size: 1.3rem;
        }

        .device-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1rem;
        }

        .device-card {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }

        .device-card h4 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .device-info {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }

        .device-status {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-ativo {
            background: #d4edda;
            color: #155724;
        }

        .status-inativo {
            background: #f8d7da;
            color: #721c24;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }

        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #555;
        }

        .notification-item {
            background: #e3f2fd;
            border-left: 4px solid #2196f3;
            padding: 1rem;
            margin-bottom: 0.5rem;
            border-radius: 5px;
            position: relative;
        }

        .notification-item.unread {
            background: #fff3e0;
            border-left-color: #ff9800;
        }

        .notification-close {
            position: absolute;
            top: 0.5rem;
            right: 0.5rem;
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            font-size: 1.2rem;
        }

        .notification-time {
            font-size: 0.8rem;
            color: #666;
            margin-top: 0.5rem;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #555;
        }

        .form-group input {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e1e8ed;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }

        .alert {
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }

        .modal.active {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }

        .empty-state {
            text-align: center;
            padding: 2rem;
            color: #666;
        }

        .empty-state h4 {
            margin-bottom: 1rem;
            color: #333;
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }

            .header-content {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .device-grid {
                grid-template-columns: 1fr;
            }

            table {
                font-size: 0.9rem;
            }

            th, td {
                padding: 0.5rem;
            }
        }

        @media (max-width: 480px) {
            .header {
                padding: 1rem;
            }

            .header h1 {
                font-size: 1.4rem;
            }

            .card {
                padding: 1rem;
            }

            .modal-content {
                padding: 1.5rem;
                width: 95%;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>🌡️ Meu Dashboard IoT</h1>
            <div class="user-info">
                <span>Olá, <?php echo htmlspecialchars($current_user['nome']); ?>!</span>
                <button class="btn btn-secondary" onclick="openModal('profileModal')">Perfil</button>
                <a href="../includes/logout.php" class="logout-btn">Sair</a>
            </div>
        </div>
    </header>

    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Estatísticas do Usuário -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_dispositivos; ?></div>
                <div class="stat-label">Meus Dispositivos</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_leituras; ?></div>
                <div class="stat-label">Total de Leituras</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $notificacoes_nao_lidas; ?></div>
                <div class="stat-label">Notificações</div>
            </div>
        </div>

        <!-- Notificações -->
        <?php if (!empty($notificacoes)): ?>
        <div class="card">
            <h3>🔔 Notificações Recentes</h3>
            <?php foreach ($notificacoes as $notif): ?>
            <div class="notification-item unread">
                <button class="notification-close" onclick="markAsRead(<?php echo $notif['id_notificacao']; ?>)">×</button>
                <strong><?php echo htmlspecialchars($notif['tipo_notificacao']); ?></strong>
                <p><?php echo htmlspecialchars($notif['mensagem']); ?></p>
                <div class="notification-time">
                    <?php echo date('d/m/Y H:i', strtotime($notif['data_hora'])); ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Meus Dispositivos -->
        <div class="card">
            <h3>📱 Meus Dispositivos</h3>
            <?php if (!empty($dispositivos)): ?>
                <div class="device-grid">
                    <?php foreach ($dispositivos as $dispositivo): ?>
                    <div class="device-card">
                        <h4><?php echo htmlspecialchars($dispositivo['nome']); ?></h4>
                        <div class="device-info">
                            <strong>Localização:</strong> <?php echo htmlspecialchars($dispositivo['localizacao']); ?>
                        </div>
                        <div class="device-info">
                            <strong>Modelo:</strong> <?php echo htmlspecialchars($dispositivo['modelo']); ?>
                        </div>
                        <div class="device-info">
                            <strong>Criado em:</strong> <?php echo date('d/m/Y', strtotime($dispositivo['criado_em'])); ?>
                        </div>
                        <span class="device-status status-<?php echo $dispositivo['status']; ?>">
                            <?php echo ucfirst($dispositivo['status']); ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <h4>Nenhum dispositivo cadastrado</h4>
                    <p>Entre em contato com o administrador para cadastrar seus dispositivos IoT.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Leituras Recentes -->
        <div class="card">
            <h3>📊 Leituras Recentes</h3>
            <?php if (!empty($leituras_recentes)): ?>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Dispositivo</th>
                                <th>Sensor</th>
                                <th>Valor</th>
                                <th>Unidade</th>
                                <th>Status Roupa</th>
                                <th>Data/Hora</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($leituras_recentes as $leitura): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($leitura['dispositivo_nome']); ?></td>
                                <td><?php echo htmlspecialchars($leitura['tipo_sensor']); ?></td>
                                <td><?php echo $leitura['valor']; ?></td>
                                <td><?php echo htmlspecialchars($leitura['unidade_medida']); ?></td>
                                <td>
                                    <span class="device-status <?php echo $leitura['status_roupa'] === 'Seca' ? 'status-ativo' : 'status-inativo'; ?>">
                                        <?php echo $leitura['status_roupa']; ?>
                                    </span>
                                </td>
                                <td><?php echo date('d/m/Y H:i:s', strtotime($leitura['data_hora'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <h4>Nenhuma leitura encontrada</h4>
                    <p>Suas leituras dos sensores aparecerão aqui quando disponíveis.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Informações do Sistema -->
        <div class="card">
            <h3>ℹ️ Informações do Sistema</h3>
            <p><strong>Sistema:</strong> Grampo IoT - Monitoramento Inteligente de Roupas</p>
            <p><strong>Versão:</strong> 1.0.0</p>
            <p><strong>Seu cadastro:</strong> <?php echo date('d/m/Y', strtotime($current_user['criado_em'])); ?></p>
            <p><strong>Última atualização:</strong> <?php echo date('d/m/Y H:i:s', strtotime($current_user['atualizado_em'])); ?></p>
        </div>
    </div>

    <!-- Modal do Perfil -->
    <div id="profileModal" class="modal">
        <div class="modal-content">
            <h3>👤 Meu Perfil</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Nome Completo:</label>
                    <input type="text" name="nome" value="<?php echo htmlspecialchars($current_user['nome']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" value="<?php echo htmlspecialchars($current_user['email']); ?>" disabled>
                    <small style="color: #666;">Email não pode ser alterado</small>
                </div>
                
                <div class="form-group">
                    <label>CPF:</label>
                    <input type="text" value="<?php echo formatCPF($current_user['cpf']); ?>" disabled>
                    <small style="color: #666;">CPF não pode ser alterado</small>
                </div>
                
                <div class="form-group">
                    <label>Celular:</label>
                    <input type="text" name="celular" value="<?php echo htmlspecialchars($current_user['celular']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Data de Nascimento:</label>
                    <input type="date" value="<?php echo $current_user['data_nascimento']; ?>" disabled>
                    <small style="color: #666;">Data de nascimento não pode ser alterada</small>
                </div>
                
                <hr style="margin: 1.5rem 0;">
                
                <h4 style="margin-bottom: 1rem;">Alterar Senha (opcional)</h4>
                
                <div class="form-group">
                    <label>Nova Senha:</label>
                    <input type="password" name="nova_senha" minlength="6">
                    <small style="color: #666;">Deixe em branco para manter a senha atual</small>
                </div>
                
                <div class="form-group">
                    <label>Confirmar Nova Senha:</label>
                    <input type="password" name="confirmar_senha" minlength="6">
                </div>
                
                <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 2rem;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('profileModal')">Cancelar</button>
                    <button type="submit" name="update_profile" class="btn btn-primary">Salvar Alterações</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).classList.add('active');
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }

        function markAsRead(notificationId) {
            window.location.href = 'dashboard.php?mark_read=' + notificationId;
        }

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }

        // Validar confirmação de senha
        document.querySelector('input[name="confirmar_senha"]').addEventListener('blur', function() {
            const novaSenha = document.querySelector('input[name="nova_senha"]').value;
            const confirmarSenha = this.value;
            
            if (novaSenha && confirmarSenha && novaSenha !== confirmarSenha) {
                this.setCustomValidity('As senhas não coincidem');
            } else {
                this.setCustomValidity('');
            }
        });

        // Validar em tempo real
        document.querySelector('input[name="nova_senha"]').addEventListener('input', function() {
            const confirmarSenha = document.querySelector('input[name="confirmar_senha"]');
            if (confirmarSenha.value && this.value !== confirmarSenha.value) {
                confirmarSenha.setCustomValidity('As senhas não coincidem');
            } else {
                confirmarSenha.setCustomValidity('');
            }
        });

        // Máscara para celular
        document.querySelector('input[name="celular"]').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length === 11) {
                value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
            } else if (value.length === 10) {
                value = value.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
            }
            e.target.value = value;
        });

        // Auto-refresh a cada 30 segundos para atualizar leituras
        setInterval(function() {
            // Só recarrega se não houver modal aberto
            if (!document.querySelector('.modal.active')) {
                // Recarregar apenas a seção de leituras via AJAX seria melhor
                // Por simplicidade, vamos apenas recarregar a página se necessário
                console.log('Verificando novas leituras...');
            }
        }, 30000);
    </script>
</body>
</html>