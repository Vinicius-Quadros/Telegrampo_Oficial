<?php
require_once 'includes/auth.php';

$error = '';
$success = '';

// Processar reset de senha
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = sanitize($_POST['token']);
    $nova_senha = $_POST['nova_senha'];
    $confirmar_senha = $_POST['confirmar_senha'];
    
    if (empty($token) || empty($nova_senha) || empty($confirmar_senha)) {
        $error = 'Por favor, preencha todos os campos!';
    } elseif ($nova_senha !== $confirmar_senha) {
        $error = 'As senhas não coincidem!';
    } elseif (strlen($nova_senha) < 6) {
        $error = 'A senha deve ter pelo menos 6 caracteres!';
    } else {
        $result = resetPassword($token, $nova_senha);
        if ($result['success']) {
            header('Location: login.php?success=password_reset');
            exit;
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha - Grampo IoT</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .reset-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .logo {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo h1 {
            color: #333;
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .logo p {
            color: #666;
            font-size: 0.9rem;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #555;
        }

        input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e8ed;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        input:focus {
            outline: none;
            border-color: #667eea;
        }

        .btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 15px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background: #f8f9fa;
            color: #666;
            border: 2px solid #e1e8ed;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .btn-secondary:hover {
            background: #e9ecef;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
        }

        .back-link a:hover {
            text-decoration: underline;
        }

        /* Responsividade */
        @media (max-width: 480px) {
            .reset-container {
                padding: 30px 20px;
            }

            .logo h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <div class="logo">
            <h1>🔑 Redefinir Senha</h1>
            <p>Digite o token e sua nova senha</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="token">Token de Recuperação:</label>
                <input type="text" id="token" name="token" required 
                       value="<?php echo isset($_POST['token']) ? htmlspecialchars($_POST['token']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="nova_senha">Nova Senha:</label>
                <input type="password" id="nova_senha" name="nova_senha" minlength="6" required>
            </div>
            
            <div class="form-group">
                <label for="confirmar_senha">Confirmar Senha:</label>
                <input type="password" id="confirmar_senha" name="confirmar_senha" minlength="6" required>
            </div>
            
            <button type="submit" class="btn btn-primary">Alterar Senha</button>
        </form>

        <div class="back-link">
            <a href="login.php">← Voltar ao Login</a>
        </div>
    </div>

    <script>
        // Validar confirmação de senha
        document.getElementById('confirmar_senha').addEventListener('blur', function() {
            const senha = document.getElementById('nova_senha').value;
            const confirmar = this.value;
            
            if (senha !== confirmar) {
                this.setCustomValidity('As senhas não coincidem');
            } else {
                this.setCustomValidity('');
            }
        });

        // Validar em tempo real
        document.getElementById('nova_senha').addEventListener('input', function() {
            const confirmar = document.getElementById('confirmar_senha');
            if (confirmar.value && this.value !== confirmar.value) {
                confirmar.setCustomValidity('As senhas não coincidem');
            } else {
                confirmar.setCustomValidity('');
            }
        });
    </script>
</body>
</html>