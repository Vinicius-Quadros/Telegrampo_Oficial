<?php
require_once 'includes/auth.php';

// Se já estiver logado, redirecionar
if (isLoggedIn()) {
    redirectByUserType();
}

$error = '';
$success = '';

// Processar login
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = sanitize($_POST['email']);
    $senha = $_POST['senha'];
    
    if (empty($email) || empty($senha)) {
        $error = 'Por favor, preencha todos os campos!';
    } else {
        if (login($email, $senha)) {
            redirectByUserType();
        } else {
            $error = 'Email ou senha incorretos!';
        }
    }
}

// Processar cadastro
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $dados = [
        'nome' => sanitize($_POST['nome']),
        'cpf' => preg_replace('/[^0-9]/', '', $_POST['cpf']),
        'celular' => sanitize($_POST['celular']),
        'email' => sanitize($_POST['email']),
        'senha' => $_POST['senha'],
        'data_nascimento' => $_POST['data_nascimento'],
        'tipo_usuario' => 'C'
    ];
    
    // Validações
    if (empty($dados['nome']) || empty($dados['cpf']) || empty($dados['celular']) || 
        empty($dados['email']) || empty($dados['senha']) || empty($dados['data_nascimento'])) {
        $error = 'Por favor, preencha todos os campos!';
    } elseif (!validateCPF($dados['cpf'])) {
        $error = 'CPF inválido!';
    } elseif (!validateEmail($dados['email'])) {
        $error = 'Email inválido!';
    } elseif (strlen($dados['senha']) < 6) {
        $error = 'A senha deve ter pelo menos 6 caracteres!';
    } else {
        $result = registerUser($dados);
        if ($result['success']) {
            $success = $result['message'];
        } else {
            $error = $result['message'];
        }
    }
}

// Processar recuperação de senha
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reset_password'])) {
    $email = sanitize($_POST['reset_email']);
    
    if (empty($email)) {
        $error = 'Por favor, digite seu email!';
    } elseif (!validateEmail($email)) {
        $error = 'Email inválido!';
    } else {
        $result = generatePasswordResetToken($email);
        if ($result['success']) {
            $success = 'Link de recuperação enviado! Use o token: ' . $result['token'];
        } else {
            $error = $result['message'];
        }
    }
}

// Verificar se há mensagens na URL
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'unauthorized':
            $error = 'Você precisa fazer login para acessar esta página!';
            break;
        case 'forbidden':
            $error = 'Acesso negado!';
            break;
    }
}

if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case 'password_reset':
            $success = 'Senha alterada com sucesso! Faça login com a nova senha.';
            break;
        case 'logout':
            $success = 'Logout realizado com sucesso!';
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Grampo IoT</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .logo {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo h1 {
            color: #333;
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .logo p {
            color: #666;
            font-size: 0.9rem;
        }

        .form-tabs {
            display: flex;
            margin-bottom: 30px;
            background: #f8f9fa;
            border-radius: 10px;
            padding: 5px;
        }

        .tab-btn {
            flex: 1;
            padding: 10px;
            border: none;
            background: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .tab-btn.active {
            background: white;
            color: #667eea;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .form-container {
            display: none;
        }

        .form-container.active {
            display: block;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #555;
        }

        input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e8ed;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        input:focus {
            outline: none;
            border-color: #667eea;
        }

        .btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 15px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background: #f8f9fa;
            color: #666;
            border: 2px solid #e1e8ed;
        }

        .btn-secondary:hover {
            background: #e9ecef;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .forgot-password {
            text-align: center;
            margin-top: 15px;
        }

        .forgot-password a {
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
        }

        .forgot-password a:hover {
            text-decoration: underline;
        }

        /* Responsividade */
        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
            }

            .logo h1 {
                font-size: 1.5rem;
            }

            .tab-btn {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <h1>🌡️ Grampo IoT</h1>
            <p>Sistema de Monitoramento Inteligente</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="form-tabs">
            <button class="tab-btn active" onclick="showTab('login')">Entrar</button>
            <button class="tab-btn" onclick="showTab('register')">Cadastrar</button>
            <button class="tab-btn" onclick="showTab('forgot')">Esqueci</button>
        </div>

        <!-- Formulário de Login -->
        <div id="login" class="form-container active">
            <form method="POST">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="senha">Senha:</label>
                    <input type="password" id="senha" name="senha" required>
                </div>
                
                <button type="submit" name="login" class="btn btn-primary">Entrar</button>
            </form>
        </div>

        <!-- Formulário de Cadastro -->
        <div id="register" class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label for="reg_nome">Nome Completo:</label>
                    <input type="text" id="reg_nome" name="nome" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_cpf">CPF:</label>
                    <input type="text" id="reg_cpf" name="cpf" placeholder="000.000.000-00" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_celular">Celular:</label>
                    <input type="text" id="reg_celular" name="celular" placeholder="(00) 00000-0000" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_email">Email:</label>
                    <input type="email" id="reg_email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_senha">Senha:</label>
                    <input type="password" id="reg_senha" name="senha" minlength="6" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_data">Data de Nascimento:</label>
                    <input type="date" id="reg_data" name="data_nascimento" required>
                </div>
                
                <button type="submit" name="register" class="btn btn-primary">Cadastrar</button>
            </form>
        </div>

        <!-- Formulário de Recuperação -->
        <div id="forgot" class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label for="reset_email">Email para recuperação:</label>
                    <input type="email" id="reset_email" name="reset_email" required>
                </div>
                
                <button type="submit" name="reset_password" class="btn btn-primary">Enviar Token</button>
                <button type="button" class="btn btn-secondary" onclick="showResetForm()">Tenho o Token</button>
            </form>
            
            <!-- Formulário para usar o token -->
            <div id="token-form" style="display: none; margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee;">
                <form method="POST" action="reset_password.php">
                    <div class="form-group">
                        <label for="token">Token de Recuperação:</label>
                        <input type="text" id="token" name="token" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="nova_senha">Nova Senha:</label>
                        <input type="password" id="nova_senha" name="nova_senha" minlength="6" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmar_senha">Confirmar Senha:</label>
                        <input type="password" id="confirmar_senha" name="confirmar_senha" minlength="6" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Alterar Senha</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showTab(tab) {
            // Remover classe active de todas as abas
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.form-container').forEach(container => container.classList.remove('active'));
            
            // Ativar aba selecionada
            event.target.classList.add('active');
            document.getElementById(tab).classList.add('active');
        }

        function showResetForm() {
            document.getElementById('token-form').style.display = 'block';
        }

        // Máscara para CPF
        document.getElementById('reg_cpf').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
            e.target.value = value;
        });

        // Máscara para celular
        document.getElementById('reg_celular').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length === 11) {
                value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
            } else if (value.length === 10) {
                value = value.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
            }
            e.target.value = value;
        });

        // Validar confirmação de senha
        document.getElementById('confirmar_senha').addEventListener('blur', function() {
            const senha = document.getElementById('nova_senha').value;
            const confirmar = this.value;
            
            if (senha !== confirmar) {
                this.setCustomValidity('As senhas não coincidem');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>